﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Falling_Distance
{
    public partial class Form1 : Form
    {
        //Constant field for gravity.
        private const double GRAV = 9.8;

        public Form1()
        {
            InitializeComponent();
        }
        private double FallingDistance (double time)
        {

        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            double time;
            double distance;

        }
    }
}
