﻿/**
* 03/08/2018
* CSC 153
* Anthony O'Brien
* calculates organsim growth rates.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Population
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //Variables
            double start;       //Starting organisms holder
            double days;        //Amount of days holder
            double increase;    //Increased about of days holder
            int count = 1;      //Loop counter

            double.TryParse(dayTextBox.Text, out increase);
            double.TryParse(organismTextBox.Text, out start);
            double.TryParse(dailyTextBox.Text, out days);

            do
            {
                if (count != 1)
                {
                    start = (start * days) + start;
                    approximatePopListBox.Items.Add(start);
                    count = count + 1;
                }
                else
                {
                    approximatePopListBox.Items.Add(start);
                    count = count + 1;
                }

            } while (count <= increase);

            
        }
    }
}
