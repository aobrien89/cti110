﻿/**
* 05/10/2018
* CSC 153
* Anthony O'Brien
* Creates a Pet Class
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pet_Class
{
    class Pet
    {
        private string _name;
        private string _type;
        private string _age;

        public Pet()
        {
            _name = " ";
            _type = " ";
        }
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }
        public string Type
        {
            get
            {
                return _type;
            }
            set
            {
                _type = value;
            }
        }
        public string Age
        {
            get
            {
                return _age;
            }
            set
            {
                _age = value;
            }
        }
    }
}
