﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pet_Class
{
    public partial class Form1 : Form
    {
        List<Pet> petList = new List<Pet>();

        public Form1()
        {
            InitializeComponent();
        }
        private void GetPetData(Pet myPet)
        {
            string pet;
            myPet.Name = nameTextBox.Text;
            myPet.Type = typeTextBox.Text;
            myPet.Age = ageTextBox.Text;
            
            
        }
    }
}
